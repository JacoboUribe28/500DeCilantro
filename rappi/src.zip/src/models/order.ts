export interface Order{
    id?: string;
    quantity?: number;
    total_price?: number;
    status?: string;
    customer_id?: number;
    menu_id?: number;
    motorcycle_id?: number;
}