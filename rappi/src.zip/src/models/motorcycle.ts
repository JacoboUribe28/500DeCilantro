export interface Motorcycle {
    id?: string;
    license_plate?: string;
    brand?: string;
    year?: number;
    status?: string; 

}