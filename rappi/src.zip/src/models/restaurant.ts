export interface Restaurant{
    id?: string;
    name?: string;
    address?: string;
    phone?: string;
    email?: string;
}