export interface Photo{
    id?: string;
    image_url?: string;
    caption?: string;
    taken_at?: Date;
    issue_id?: number;
}