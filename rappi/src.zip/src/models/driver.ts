export interface Driver{
    id?: string;
    name?: string;
    license_number?: string;
    email?: string;
    phone?: string;
    status?: string;
}