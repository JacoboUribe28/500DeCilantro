export interface Menu{
    id?: string;
    price?: number;
    availbality?: boolean;
    restaurant_id?: number;
    product_id?: number;
}