export interface Shift {
    id?: string;
    start_time?: Date;
    end_time?: Date;
    status?: string;
    driver_id?: number;
    motorcycle_id?: number;
}